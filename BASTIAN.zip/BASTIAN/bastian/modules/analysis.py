"""Analysis module: HTTP, SSL/TLS, DNS, WHOIS and technology fingerprinting."""

import socket
import ssl
import time

from .. import color
from ..http import Client


SECURITY_HEADERS = [
    ("strict-transport-security", "HSTS enabled"),
    ("content-security-policy", "CSP defined"),
    ("x-frame-options", "Clickjacking protection"),
    ("x-content-type-options", "MIME sniffing protection"),
    ("referrer-policy", "Referrer policy set"),
    ("permissions-policy", "Browser feature policy set"),
]


def _resolve_ip(host):
    try:
        infos = socket.getaddrinfo(host, None)
    except (socket.gaierror, OSError):
        return []
    ips = {i[4][0] for i in infos}
    return sorted([ip for ip in ips if ":" not in ip]) + sorted(
        [ip for ip in ips if ":" in ip]
    )


def _doh(client, name, qtype):
    url = "https://dns.google/resolve?name={}&type={}".format(name, qtype)
    resp = client.get(url, timeout=8)
    if not resp.status:
        return []
    try:
        data = resp.json()
    except (ValueError, TypeError):
        return []
    return [str(a.get("data", "")) for a in data.get("Answer", [])]


def dns_records(client, domain):
    """Collect A/AAAA/MX/NS/TXT/CNAME via DoH with a socket fallback."""
    results = {}
    results["A"] = _doh(client, domain, "A") or _resolve_ip(domain)
    results["AAAA"] = _doh(client, domain, "AAAA")
    results["MX"] = _doh(client, domain, "MX")
    results["NS"] = _doh(client, domain, "NS")
    results["TXT"] = _doh(client, domain, "TXT")
    results["CNAME"] = _doh(client, domain, "CNAME")
    return results


def ssl_info(host, port, timeout=8):
    """Return TLS/certificate details, or None on failure."""
    ctx = ssl.create_default_context()
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE
    try:
        sock = socket.create_connection((host, port), timeout=timeout)
    except OSError:
        return None
    try:
        with ctx.wrap_socket(sock, server_hostname=host) as s:
            cert = s.getpeercert()
            cipher = s.cipher()
            version = s.version()
    except (ssl.SSLError, OSError, ValueError):
        return None
    return {"cert": cert, "cipher": cipher, "version": version}


def _cert_lines(cert, host, port):
    if not cert:
        return ["No usable TLS certificate (or port not TLS)."]
    lines = []
    for key in ("subject", "issuer"):
        parts = cert.get(key, ())
        if parts:
            pairs = ["{}={}".format(k, v) for k, v in parts]
            lines.append("{}: {}".format(key.title(), ", ".join(pairs)))
    san = cert.get("subjectAltName", ())
    lines.append("SAN      : " + ", ".join(san))
    lines.append("Serial   : " + str(cert.get("serialNumber", "?")))
    not_before = cert.get("notBefore", "")
    not_after = cert.get("notAfter", "")
    lines.append("NotBefore: " + not_before)
    lines.append("NotAfter : " + not_after)
    if not_after:
        try:
            exp = ssl.cert_time_to_seconds(not_after)
            days = int((exp - time.time()) / 86400)
            state = "OK" if days > 30 else ("expires soon" if days > 0 else "EXPIRED")
            lines.append("Expires  : in {} days  [{}]".format(days, state))
        except (ValueError, TypeError):
            pass
    return lines


def whois(domain, timeout=10):
    """Query WHOIS via referral (IANA -> authoritative registrar server)."""
    query = domain + "\r\n"
    try:
        with socket.create_connection(("whois.iana.org", 43), timeout=timeout) as s:
            s.sendall(query.encode())
            data = b""
            while True:
                chunk = s.recv(4096)
                if not chunk:
                    break
                data += chunk
    except OSError:
        return ""
    text = data.decode("utf-8", errors="replace")

    referral = None
    for line in text.splitlines():
        low = line.lower()
        if low.startswith("refer:") or low.startswith("whois:"):
            referral = line.split(":", 1)[1].strip()
            break
    if referral:
        try:
            with socket.create_connection((referral, 43), timeout=timeout) as s:
                s.sendall(query.encode())
                data = b""
                while True:
                    chunk = s.recv(4096)
                    if not chunk:
                        break
                    data += chunk
            text = data.decode("utf-8", errors="replace")
        except OSError:
            pass
    return text


def _whois_lines(text):
    if not text:
        return ["WHOIS query failed or no data returned."]
    keep = []
    interested = (
        "registrar", "creation date", "created", "expir", "updated",
        "name server", "status", "registrant", "organization", "country",
        "state", "admin",
    )
    for line in text.splitlines():
        low = line.lower()
        if low.startswith(("%", "#")) or not line.strip():
            continue
        if any(k in low for k in interested):
            keep.append(line.strip())
    if not keep:
        keep = [l.strip() for l in text.splitlines() if l.strip()][:25]
    return keep[:40]


def _redirect_lines(client, url):
    from urllib.parse import urljoin
    resp = client.get(url, follow_redirects=False)
    if not resp.status:
        return ["[ERROR] target unreachable"]
    lines = ["HTTP {}  {}".format(resp.status, url)]
    status = resp.status
    location = resp.headers.get("location")
    hops = 0
    seen = {url}
    while status in (301, 302, 303, 307, 308) and location and hops < 10:
        nxt = urljoin(url, location)
        if nxt in seen:
            lines.append("        -> {}  [redirect loop]".format(nxt))
            break
        seen.add(nxt)
        resp = client.get(nxt, follow_redirects=False)
        lines.append("        -> HTTP {}  {}".format(resp.status, nxt))
        status = resp.status
        location = resp.headers.get("location")
        url = nxt
        hops += 1
    return lines


def _security_lines(headers):
    lines = []
    for header, note in SECURITY_HEADERS:
        value = headers.get(header)
        if value:
            lines.append("[PRESENT] {:<28} : {}".format(header, value[:60]))
        else:
            lines.append("[MISSING] {:<28} : {}".format(header, note))
    return lines


def _tech_lines(target, headers, body):
    clues = []
    server = headers.get("server")
    powered = headers.get("x-powered-by")
    generator = headers.get("x-generator")
    if server:
        clues.append(("Server", server))
    if powered:
        clues.append(("X-Powered-By", powered))
    if generator:
        clues.append(("X-Generator", generator))

    cookies = headers.get("set-cookie", "")
    cookie_marks = {
        "phpsessid": "PHP",
        "jsessionid": "Java/JSP",
        "laravel_session": "Laravel",
        "asp.net": "ASP.NET",
        "cf_clearance": "Cloudflare",
        "wp-settings": "WordPress",
        "ci_session": "CodeIgniter",
        "csrftoken": "Django",
    }
    for mark, label in cookie_marks.items():
        if mark in cookies.lower():
            clues.append(("Cookie", label))

    html_marks = {
        "wp-content": "WordPress",
        "wp-includes": "WordPress",
        "powered by prestashop": "PrestaShop",
        "joomla": "Joomla",
        "drupal": "Drupal",
        "shopify": "Shopify",
        "vue.js": "Vue.js",
        "react": "React",
        "angular": "Angular",
        "phpmyadmin": "phpMyAdmin",
    }
    low = body.lower()
    for mark, label in html_marks.items():
        if mark in low:
            clues.append(("HTML", label))

    if not clues:
        return ["No obvious technology markers detected."]
    seen = set()
    lines = []
    for src, val in clues:
        key = (src, val)
        if key in seen:
            continue
        seen.add(key)
        lines.append("{:12} {}".format(src + ":", val))
    return lines


def run(target, cfg):
    """Entry point. Returns a list of (title, lines) report sections."""
    client = Client(timeout=cfg.timeout, proxy=cfg.resolved_proxy())
    sections = []

    print(color.tag("prog") + " analysis  : "
          + color.truecolor(target.label, "f8fafc", bold=True))

    resp = client.get(target.base_url, follow_redirects=True)
    sections.append(("REDIRECT CHAIN", _redirect_lines(client, target.base_url)))
    if resp.status:
        sections.append(("HTTP RESPONSE HEADERS",
                         ["{}: {}".format(k, v) for k, v in sorted(resp.headers.items())]))
        sections.append(("SECURITY HEADERS", _security_lines(resp.headers)))
        sections.append(("TECHNOLOGY STACK", _tech_lines(target, resp.headers, resp.text)))
    else:
        sections.append(("HTTP RESPONSE HEADERS", ["[ERROR] no HTTP response"]))

    port = target.port or (80 if target.scheme == "http" else 443)
    tlsinfo = ssl_info(target.host, port, timeout=cfg.timeout)
    if tlsinfo:
        tls_lines = [
            "Protocol : " + tlsinfo["version"],
            "Cipher   : " + (tlsinfo["cipher"][0] if tlsinfo["cipher"] else "?"),
            "Bits     : " + (str(tlsinfo["cipher"][2]) if tlsinfo["cipher"] else "?"),
        ]
        tls_lines += _cert_lines(tlsinfo["cert"], target.host, port)
        sections.append(("SSL / TLS", tls_lines))
    else:
        sections.append(("SSL / TLS",
                         ["No TLS at {}:{} (or handshake failed)".format(target.host, port)]))

    if not target.is_ip:
        records = dns_records(client, target.host)
        dns_lines = []
        for rtype in ("A", "AAAA", "CNAME", "MX", "NS", "TXT"):
            values = records[rtype]
            if values:
                dns_lines.append("{:6}: {}".format(rtype, ", ".join(values[:12])))
        sections.append(("DNS RECORDS", dns_lines or ["No DNS records resolved."]))

    if not target.is_ip:
        sections.append(("WHOIS", _whois_lines(whois(target.host, timeout=cfg.timeout))))

    res_lines = []
    for path in ("robots.txt", "sitemap.xml"):
        r = client.get(target.base_url + "/" + path)
        res_lines.append("{:16} : HTTP {}  ({} bytes)".format(path, r.status, len(r.text)))
    r = client.get(target.base_url + "/.well-known/security.txt")
    res_lines.append("{:16} : HTTP {}".format("security.txt", r.status))
    sections.append(("WELL-KNOWN RESOURCES", res_lines))

    return sections