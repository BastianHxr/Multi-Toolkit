"""Scanning module: TCP port scan, directory brute-force, sensitive files."""

import socket
from concurrent.futures import ThreadPoolExecutor, as_completed

from .. import color
from ..http import Client


DIR_WORDLIST = [
    "admin", "administrator", "login", "wp-admin", "wp-login.php",
    "api", "api/v1", "v1", "v2", "graphql", "rest", "backup", "backups",
    "config", "configuration", "dashboard", "panel", "uploads", "upload",
    "images", "img", "css", "js", "assets", "static", "public", "docs",
    "doc", "test", "tests", "dev", "staging", "beta", "old", "new",
    "phpmyadmin", "pma", "adminer", "mysql", "db", "sql", "database",
    "includes", "inc", "lib", "vendor", "node_modules", "composer.json",
    "package.json", "robots.txt", "sitemap.xml", "readme", "info",
    "install", "setup", "console", "shell", "status", "health", "ping",
    "version", "git", "svn", "tmp", "temp", "logs", "log", "error_log",
    "cgi-bin", "cpanel", "webmail", "mail", "owa", "zimbra", "manager",
    "tomcat", "jenkins", "grafana", "kibana", "solr", "actuator",
]

SENSITIVE_PATHS = [
    (".git/config", "Git repository exposed"),
    (".git/HEAD", "Git repository exposed"),
    (".env", "Environment variables exposed"),
    (".env.local", "Laravel environment exposed"),
    (".env.production", "Production environment exposed"),
    (".svn/entries", "SVN metadata exposed"),
    (".htaccess", "Apache config exposed"),
    (".htpasswd", "Apache credential file"),
    ("web.config", "IIS configuration exposed"),
    ("backup.zip", "Backup archive exposed"),
    ("backup.tar.gz", "Backup archive exposed"),
    ("backup.sql", "Database backup exposed"),
    ("database.sql", "Database dump exposed"),
    ("db.sql", "Database dump exposed"),
    ("dump.sql", "Database dump exposed"),
    ("wp-config.php.bak", "WordPress config backup"),
    ("wp-config.php~", "WordPress config backup"),
    ("wp-config.php.save", "WordPress config backup"),
    ("config.php.bak", "Config backup"),
    ("config.yml.bak", "Config backup"),
    ("phpinfo.php", "PHP info disclosure"),
    ("server-status", "Apache server status"),
    ("server-info", "Apache server info"),
    ("actuator", "Spring Boot Actuator"),
    ("actuator/env", "Spring Boot environment"),
    ("actuator/health", "Spring Boot health"),
    (".DS_Store", "macOS metadata leak"),
    ("crossdomain.xml", "Flash cross-domain policy"),
    ("clientaccesspolicy.xml", "Silverlight policy"),
    ("phpunit.xml", "PHPUnit configuration"),
    ("trace.axd", "ASP.NET trace"),
    ("elmah.axd", "ELMAH error log"),
    (".well-known/security.txt", "security.txt"),
    ("id_rsa", "SSH private key"),
    ("id_ed25519", "SSH private key"),
]


def _port_state(host, port, timeout):
    try:
        with socket.create_connection((host, port), timeout=timeout):
            return port, "open"
    except OSError:
        return port, "closed"


def port_scan(host, ports, threads, timeout):
    """TCP connect scan. Returns a list of (port, service) for open ports."""
    results = []
    with ThreadPoolExecutor(max_workers=max(1, min(threads, len(ports) or 1))) as ex:
        futures = {ex.submit(_port_state, host, p, timeout): p for p in ports}
        for fut in as_completed(futures):
            port, state = fut.result()
            if state == "open":
                try:
                    service = socket.getservbyport(port)
                except OSError:
                    service = "unknown"
                results.append((port, service))
    results.sort()
    return results


def _fetch_status(client, url):
    resp = client.get(url, follow_redirects=False, timeout=client.timeout)
    return url, resp.status, len(resp.text)


def directory_fuzz(client, base_url, wordlist_path, threads, timeout):
    """Brute-force common directories/files. Returns (path, status, size)."""
    if wordlist_path:
        try:
            with open(wordlist_path, "r", encoding="utf-8", errors="ignore") as fh:
                words = [l.strip() for l in fh
                         if l.strip() and not l.strip().startswith("#")]
        except OSError:
            words = list(DIR_WORDLIST)
    else:
        words = list(DIR_WORDLIST)

    urls = ["{}/{}".format(base_url.rstrip("/"), w.lstrip("/")) for w in words]
    found = []
    interesting = {200, 201, 204, 301, 302, 307, 308, 401, 403}
    with ThreadPoolExecutor(max_workers=max(1, min(threads, len(urls)))) as ex:
        futures = {ex.submit(_fetch_status, client, u): u for u in urls}
        done = 0
        total = len(urls)
        for fut in as_completed(futures):
            url, status, size = fut.result()
            done += 1
            if status in interesting:
                path = url[len(base_url.rstrip("/")):]
                found.append((path, status, size))
            if done % 25 == 0 or done == total:
                print(color.tag("prog") + " fuzzing   : {}/{} paths".format(done, total))
    found.sort(key=lambda x: x[0])
    return found


def sensitive_check(client, base_url):
    """Check for exposed sensitive files. Returns (path, status, note)."""
    found = []
    for path, note in SENSITIVE_PATHS:
        url = "{}/{}".format(base_url.rstrip("/"), path.lstrip("/"))
        resp = client.get(url, follow_redirects=False)
        if resp.status in (200, 301, 302, 307, 308, 401, 403):
            found.append((path, resp.status, note))
    return found


def run(target, cfg):
    """Entry point. Returns a list of (title, lines) report sections."""
    client = Client(timeout=cfg.timeout, proxy=cfg.resolved_proxy())
    sections = []

    print(color.tag("prog") + " scanning  : "
          + color.truecolor(target.label, "f8fafc", bold=True))

    ports = cfg.ports[: cfg.max_ports]
    print(color.tag("prog") + " portscan  : {} ports on {}".format(len(ports), target.host))
    open_ports = port_scan(target.host, ports, cfg.threads, cfg.timeout)
    if open_ports:
        lines = ["{:<6} {}".format(p, svc) for p, svc in open_ports]
    else:
        lines = ["No open ports detected in the selected range."]
    sections.append(("OPEN PORTS", lines))

    print(color.tag("prog") + " dirfuzz   : " + target.base_url)
    dirs = directory_fuzz(client, target.base_url, cfg.wordlist, cfg.threads, cfg.timeout)
    if dirs:
        lines = ["{:<36} {:>4} {:>8}".format(p, status, size) for p, status, size in dirs]
    else:
        lines = ["No interesting paths found."]
    sections.append(("DIRECTORY / FILE FUZZ", lines))

    print(color.tag("prog") + " sensitive : checking exposed files")
    sens = sensitive_check(client, target.base_url)
    if sens:
        lines = []
        for path, status, note in sens:
            flag = "[FLAGGED]" if status == 200 else "[NOTICE]"
            lines.append("{} {:<38} HTTP {}  ({})".format(flag, path, status, note))
    else:
        lines = ["No sensitive files exposed."]
    sections.append(("SENSITIVE FILES", lines))

    return sections
