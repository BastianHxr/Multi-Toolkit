"""Reputation module: geolocation, URLhaus, DNSBL and optional threat APIs."""

import ipaddress
import socket
from urllib.parse import urlencode

from .. import color
from ..http import Client


DNSBL_SERVERS = [
    "zen.spamhaus.org",
    "bl.spamcop.net",
    "dnsbl.sorbs.net",
    "b.barracudacentral.org",
    "cbl.abuseat.org",
]


def _resolve_ip(host):
    try:
        infos = socket.getaddrinfo(host, None)
    except (socket.gaierror, OSError):
        return []
    ips = {i[4][0] for i in infos}
    return sorted([ip for ip in ips if ":" not in ip]) + sorted(
        [ip for ip in ips if ":" in ip]
    )


def _is_private(ip):
    try:
        return ipaddress.ip_address(ip).is_private
    except ValueError:
        return True


def _reverse_ip(ip):
    if ":" in ip:
        return ip
    return ".".join(reversed(ip.split(".")))


def ipinfo(client, ip):
    """Free geolocation lookup via ip-api.com (HTTP, no key)."""
    url = ("http://ip-api.com/json/{}?fields=status,message,query,country,"
           "countryCode,region,city,isp,org,as,reverse,proxy,hosting").format(ip)
    resp = client.get(url, timeout=8)
    if not resp.status:
        return None
    try:
        data = resp.json()
    except (ValueError, TypeError):
        return None
    if not isinstance(data, dict) or data.get("status") != "success":
        return None
    return data


def urlhaus_host(client, host):
    """Check a host/domain against the URLhaus malware feed (no key)."""
    url = "https://urlhaus-api.abuse.ch/v1/host/"
    body = urlencode({"host": host})
    resp = client.post(url, data=body,
                       headers={"Content-Type": "application/x-www-form-urlencoded"})
    if not resp.status:
        return None
    try:
        data = resp.json()
    except (ValueError, TypeError):
        return None
    return data


def urlhaus_url(client, full_url):
    """Check a URL against URLhaus (no key)."""
    url = "https://urlhaus-api.abuse.ch/v1/url/"
    body = urlencode({"url": full_url})
    resp = client.post(url, data=body,
                       headers={"Content-Type": "application/x-www-form-urlencoded"})
    if not resp.status:
        return None
    try:
        return resp.json()
    except (ValueError, TypeError):
        return None


def dnsbl(ip):
    """Check an IP against public DNS blacklists. Returns list of listings."""
    if _is_private(ip):
        return ["(private/reserved IP - skipped)"]
    rev = _reverse_ip(ip)
    if ":" in rev:
        return ["(IPv6 - skipped)"]
    listed = []
    for server in DNSBL_SERVERS:
        query = "{}.{}".format(rev, server)
        try:
            ans = socket.gethostbyname(query)
            if ans.startswith("127."):
                listed.append(server)
        except socket.gaierror:
            continue
    return listed


def _ipinfo_lines(data):
    if not data:
        return ["No geolocation data returned."]
    rows = [
        ("IP", data.get("query", "?")),
        ("Country", "{country} ({countryCode})".format(**data)),
        ("Region", data.get("region", "?")),
        ("City", data.get("city", "?")),
        ("ISP", data.get("isp", "?")),
        ("Org", data.get("org", "?")),
        ("ASN", data.get("as", "?")),
        ("Reverse", data.get("reverse", "?")),
        ("Proxy/VPN", "yes" if data.get("proxy") else "no"),
        ("Hosting", "yes" if data.get("hosting") else "no"),
    ]
    width = max(len(k) for k, _ in rows)
    return ["{:<{w}} : {}".format(k, v, w=width) for k, v in rows]


def _urlhaus_lines(data):
    if data is None:
        return ["URLhaus lookup failed."]
    q = data.get("query_status")
    if q in ("no_results", "invalid_url"):
        return ["No matches in URLhaus (clean)."]
    if q == "ok":
        lines = ["Host listed in URLhaus malware feed!"]
        if data.get("first_seen"):
            lines.append("First seen : " + data["first_seen"])
        if data.get("blacklists"):
            bl = data["blacklists"]
            lines.append("Blacklists : {} / {} flagged".format(
                bl.get("count", "?"), bl.get("detections", "?")))
        urls = data.get("urls", [])
        lines.append("Malicious URLs:")
        for entry in urls[:10]:
            lines.append("  - {}  [{}]".format(entry.get("url", "?"), entry.get("url_status", "?")))
        return lines
    return ["URLhaus response: " + str(data.get("query_status", "unknown"))]


def _vt_lines(data):
    if data is None:
        return ["VirusTotal lookup failed (check API key / quota)."]
    if "data" not in data:
        return ["VirusTotal: " + str(data.get("error", {}).get("message", "unknown"))]
    attrs = data["data"].get("attributes", {})
    stats = attrs.get("last_analysis_stats", {})
    lines = [
        "Reputation    : " + attrs.get("reputation", "?") + "",
        "Votes         : " + "malicious={} harmless={}".format(
            stats.get("malicious", "?"), stats.get("harmless", "?")),
        "Engines       : {} total".format(sum(stats.values())),
        "Last analysed : " + str(attrs.get("last_analysis_date", "?")),
    ]
    cats = attrs.get("categories", {})
    malicious = {k: v for k, v in cats.items() if v not in ("harmless", "undetected", "")}
    if malicious:
        lines.append("Categories    : " + ", ".join("{}={}".format(k, v) for k, v in list(malicious.items())[:8]))
    return lines


def _abipdb_lines(data):
    if data is None:
        return ["AbuseIPDB lookup failed."]
    d = data.get("data", {})
    if not d:
        return ["AbuseIPDB: " + str(data.get("errors", "no data"))]
    lines = [
        "IP            : " + d.get("ipAddress", "?"),
        "Abuse score   : {} / 100".format(d.get("abuseConfidenceScore", 0)),
        "Reports       : {} total".format(d.get("totalReports", 0)),
        "ISP           : " + d.get("isp", "?"),
        "Domain        : " + (d.get("domain") or "?"),
        "Usage type    : " + d.get("usageType", "?"),
        "Country       : " + (d.get("countryName") or "?"),
    ]
    return lines


def _gsb_lines(data):
    if data is None:
        return ["Safe Browsing lookup failed."]
    if not isinstance(data, dict) or "matches" not in data:
        return ["Safe Browsing: no threats found (clean)."]
    lines = []
    for m in data["matches"]:
        lines.append("Threat: {} on {}".format(m.get("threatType"), m.get("threat", {}).get("url", "?")))
    return lines


def run(target, cfg):
    """Entry point. Returns a list of (title, lines) report sections."""
    client = Client(timeout=cfg.timeout, proxy=cfg.resolved_proxy())
    keys = cfg.api_keys()
    sections = []

    print(color.tag("prog") + " reputation: "
          + color.truecolor(target.label, "f8fafc", bold=True))

    if target.is_ip:
        ips = [target.host]
        host = target.host
    else:
        host = target.host
        ips = _resolve_ip(host)

    if not ips:
        ips = [target.host]

    # Geolocation + DNSBL per IP (cap at 3 IPs to stay tidy).
    geo_lines = []
    dnsbl_lines = []
    for ip in ips[:3]:
        info = ipinfo(client, ip)
        geo_lines.append("--- {} ---".format(ip))
        geo_lines += _ipinfo_lines(info)
        geo_lines.append("")
        dnsbl_lines.append("{} : {}".format(ip, ", ".join(dnsbl(ip)) or "clean"))
    sections.append(("GEOLOCATION", geo_lines))
    sections.append(("DNS BLACKLISTS", dnsbl_lines or ["(no IPs to check)"]))

    # URLhaus (host + url).
    sections.append(("URLHAUS (HOST)", _urlhaus_lines(urlhaus_host(client, host))))
    sections.append(("URLHAUS (URL)", _urlhaus_lines(urlhaus_url(client, target.base_url))))

    # Optional: VirusTotal.
    if keys["virustotal"]:
        print(color.tag("prog") + " virustotal: " + host)
        url = "https://www.virustotal.com/api/v3/domains/{}".format(host)
        if target.is_ip:
            url = "https://www.virustotal.com/api/v3/ip_addresses/{}".format(host)
        resp = client.get(url, headers={"x-apikey": keys["virustotal"]})
        vt_data = resp.json() if resp.status else None
        sections.append(("VIRUSTOTAL", _vt_lines(vt_data)))

    # Optional: AbuseIPDB.
    if keys["abuseipdb"] and ips:
        print(color.tag("prog") + " abuseipdb : " + ips[0])
        url = ("https://api.abuseipdb.com/api/v2/check?ipAddress={}&maxAgeInDays=90"
               .format(ips[0]))
        resp = client.get(url, headers={"Key": keys["abuseipdb"],
                                        "Accept": "application/json"})
        ab_data = resp.json() if resp.status else None
        sections.append(("ABUSEIPDB", _abipdb_lines(ab_data)))

    # Optional: Google Safe Browsing.
    if keys["safebrowsing"]:
        print(color.tag("prog") + " safebrowsing: " + target.base_url)
        url = ("https://safebrowsing.googleapis.com/v4/threatMatches:find?key={}"
               .format(keys["safebrowsing"]))
        payload = {
            "client": {"clientId": "bastian", "clientVersion": "1.0.0"},
            "threatInfo": {
                "threatTypes": ["MALWARE", "SOCIAL_ENGINEERING", "UNWANTED_SOFTWARE",
                                "POTENTIALLY_HARMFUL_APPLICATION"],
                "platformTypes": ["ANY_PLATFORM"],
                "threatEntryTypes": ["URL"],
                "threatEntries": [{"url": target.base_url}],
            },
        }
        resp = client.post(url, json_data=payload)
        gsb_data = resp.json() if resp.status else None
        sections.append(("GOOGLE SAFE BROWSING", _gsb_lines(gsb_data)))

    return sections
