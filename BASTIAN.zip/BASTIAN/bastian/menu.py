"""Interactive console menu for BASTIAN (Sentinel block UI)."""

import os
import sys

from . import __version__, color, logo, ui
from .config import Settings, configure, summarize


MENU = [
    ("1", "CONFIGURE", "target, modules & options"),
    ("2", "RUN MODULES", "analysis / scanning / reputation"),
    ("3", "VIEW CONFIG", "show active settings"),
    ("4", "ABOUT / HELP", "info & disclaimer"),
    ("0", "EXIT", "close the console"),
]


def _configure_stdio():
    if os.name == "nt":
        os.system("chcp 65001 >nul 2>&1")
    for stream in (sys.stdout, sys.stderr, sys.stdin):
        try:
            stream.reconfigure(encoding="utf-8")
        except Exception:
            pass


def _ask(prompt):
    try:
        return input(
            ui.style("  ❯ ", "primary", bold=True)
            + ui.style(prompt, "body")
            + ui.style("  ", "muted")
        ).strip()
    except (EOFError, KeyboardInterrupt):
        print()
        return None


def _row(key, label, desc, width):
    inner = max(10, width - 4)
    left = ui.keycap(key) + "  " + ui.style(label, "body", bold=True)
    right = ui.style(desc, "muted")
    mid = max(2, inner - ui.vlen(left) - ui.vlen(right))
    return left + " " * mid + right


def _print_menu(cfg):
    width = ui.ui_width()
    target = cfg.targets.strip()
    if target:
        preview = target if len(target) <= width - 20 else target[:width - 21] + "…"
        print(ui.status("info", "target: " + preview))
    else:
        print(ui.status("warn", "no target configured"))
    print()

    rows = [_row(key, label, desc, width) for key, label, desc in MENU]
    footer = ui.BRAND + "  ·  " + ui.clock_now()
    print(ui.boxed(rows, title="MAIN MENU", footer=footer, width=width))


def _about():
    width = ui.ui_width()
    lines = [
        ui.style("BASTIAN v" + __version__, "bright", bold=True),
        ui.style(logo.TAGLINE, "body"),
        "",
        ui.style("ANALYSIS", "primary", bold=True) + "    headers, TLS, DNS, WHOIS, tech",
        ui.style("SCANNING", "primary", bold=True) + "    ports, directory fuzz, exposed files",
        ui.style("REPUTATION", "primary", bold=True) + "  geo, URLhaus, DNSBL, threat intel",
        "",
        ui.style("Run", "body", bold=True) + "  python bs.py  (interactive, no arguments)",
        "",
        ui.style("AUTHORIZED USE ONLY.", "err", bold=True),
        ui.style("Test only assets you own or are explicitly permitted to test.", "err"),
    ]
    print(ui.boxed(
        lines,
        title="ABOUT / HELP",
        footer="v" + __version__ + "  ·  " + ui.BRAND,
        width=width,
    ))


def main():
    _configure_stdio()
    color.set_enabled(color.auto_enable())
    print(logo.banner())
    cfg = Settings()

    while True:
        print()
        _print_menu(cfg)
        choice = _ask("select an operation")
        if choice is None:
            print(ui.status("warn", "input closed."))
            break
        choice = choice.lower()
        if choice.isdigit() and len(choice) > 1:
            choice = choice.lstrip("0") or "0"
        print()

        if choice == "1":
            try:
                cfg = configure(cfg)
                print()
                print(ui.status("ok", "configuration updated."))
            except ValueError as exc:
                print(ui.status("err", str(exc)))
        elif choice == "2":
            if not cfg.targets.strip():
                print(ui.status("err", "no target configured. Choose option 1 first."))
                continue
            print(summarize(cfg))
            confirm = _ask("run with this configuration? (y/n) [y]")
            if confirm is None:
                print(ui.status("warn", "input closed."))
                break
            if confirm.lower() in ("n", "no"):
                continue
            from . import runner
            try:
                results = runner.execute(cfg)
                print(ui.status("ok", "finished {} target(s).".format(len(results))))
            except (ValueError, OSError) as exc:
                print(ui.status("err", str(exc)))
            except KeyboardInterrupt:
                print()
                print(ui.status("warn", "interrupted by user."))
        elif choice == "3":
            print(summarize(cfg))
        elif choice == "4":
            _about()
        elif choice in ("0", "q", "quit", "exit"):
            print(ui.status("ok", "session closed."))
            break
        else:
            print(ui.status("err", "unknown option. Choose 0-4."))
