"""Settings model and the interactive configuration form (Sentinel UI)."""

import os
from dataclasses import dataclass, field, replace

from . import ui


# Top ~100 most common TCP ports (IANA + widely observed in the wild).
TOP_PORTS = [
    21, 22, 23, 25, 53, 80, 81, 110, 111, 135, 139, 143, 161, 179, 199,
    443, 445, 465, 514, 515, 548, 554, 587, 631, 636, 873, 993, 995,
    1080, 1099, 1433, 1521, 1701, 1723, 2049, 2082, 2083, 2086, 2087,
    2095, 2096, 2222, 2375, 2376, 3000, 3128, 3306, 3389, 3690, 4000,
    5000, 5432, 5632, 5900, 5984, 6379, 7001, 7002, 7474, 8000, 8008,
    8009, 8010, 8042, 8069, 8080, 8081, 8083, 8088, 8089, 8090, 8161,
    8181, 8200, 8291, 8443, 8500, 8834, 8880, 8888, 8983, 9000, 9001,
    9043, 9060, 9080, 9090, 9091, 9100, 9200, 9300, 9443, 9999, 10000,
    11211, 27017, 28017, 50000,
]

COMMON_PORTS = [21, 22, 23, 25, 53, 80, 110, 143, 443, 465, 587, 993,
                995, 3306, 3389, 5432, 5900, 8080, 8443, 9200]

MODULES = [
    ("1", "ANALYSIS", "headers, TLS, DNS, WHOIS, tech stack"),
    ("2", "SCANNING", "ports, directory fuzz, exposed files"),
    ("3", "REPUTATION", "geolocation, URLhaus, DNSBL, threat intel"),
    ("4", "ALL MODULES", "run the full suite (default)"),
]

MODULE_MAP = {
    "1": ["analysis"],
    "2": ["scanning"],
    "3": ["reputation"],
    "4": ["analysis", "scanning", "reputation"],
}

THREADS_RANGE = (1, 200)
TIMEOUT_RANGE = (1, 120)


@dataclass
class Settings:
    """Runtime configuration gathered from the interactive form."""

    targets: str = ""
    modules: list = field(default_factory=lambda: ["analysis", "scanning", "reputation"])
    threads: int = 40
    timeout: int = 10
    proxy: str = ""
    ports: list = field(default_factory=lambda: list(TOP_PORTS))
    wordlist: str = ""
    max_ports: int = 100
    vt_key: str = ""
    abuseipdb_key: str = ""
    safebrowsing_key: str = ""
    save_report: bool = True
    output_dir: str = ""

    def resolved_proxy(self):
        return {"http": self.proxy, "https": self.proxy} if self.proxy else None

    def api_keys(self):
        return {
            "virustotal": self.vt_key.strip(),
            "abuseipdb": self.abuseipdb_key.strip(),
            "safebrowsing": self.safebrowsing_key.strip(),
        }


def _hint(choices, default, required):
    if choices:
        return "[" + " / ".join(choices) + "]"
    if default not in ("", None):
        return "[default: {}]".format(default)
    return "[required]" if required else "[optional]"


def _ask(label, default="", cast=str, choices=None, required=False):
    """Prompt for one value, retrying on bad input instead of crashing."""
    hint = _hint(choices, default, required)
    print(
        "  " + ui.style("▌", "accent") + " "
        + ui.style(label, "body") + "  " + ui.style(hint, "muted")
    )
    prompt = "    " + ui.style("↳ ", "primary", bold=True)

    while True:
        try:
            raw = input(prompt)
        except EOFError:
            print()
            if required:
                raise ValueError("input cancelled; a target is required")
            if cast is bool:
                return str(default).lower() in ("y", "yes", "1", "true")
            if cast is int:
                try:
                    return int(default)
                except (TypeError, ValueError):
                    return 0
            return "" if default is None else str(default)
        except KeyboardInterrupt:
            print()
            raise ValueError("configuration cancelled")

        value = raw.strip()
        if value == "":
            value = "" if default is None else str(default)
        if choices and value not in choices:
            print(ui.status("warn", "choose one of: " + " / ".join(choices)))
            continue
        if required and not value:
            print(ui.status("warn", "this field is required."))
            continue
        if cast is int:
            try:
                return int(value)
            except ValueError:
                print(ui.status("warn", "enter a whole number."))
                continue
        if cast is bool:
            lowered = value.lower()
            if lowered in ("y", "yes", "1", "true"):
                return True
            if lowered in ("n", "no", "0", "false"):
                return False
            print(ui.status("warn", "answer y or n."))
            continue
        return cast(value)


def _section(title):
    print()
    print(ui.rule(title.upper(), title_color="accent"))


def _clamp(value, limits, label):
    low, high = limits
    if value < low or value > high:
        fixed = max(low, min(high, value))
        print(ui.status(
            "warn",
            "{} adjusted to {} (allowed {}-{}).".format(label, fixed, low, high),
        ))
        return fixed
    return value


def _module_rows(width):
    inner = max(20, width - 4)
    rows = []
    for key, label, desc in MODULES:
        left = ui.keycap(key) + "  " + ui.style(label, "body", bold=True)
        right = ui.style(desc, "muted")
        gap = max(2, inner - ui.vlen(left) - ui.vlen(right))
        rows.append(left + " " * gap + right)
    return rows


def _module_default(modules):
    for key, names in MODULE_MAP.items():
        if names == list(modules):
            return key
    return "4"


def _ports_default(ports):
    if ports == TOP_PORTS:
        return "top100"
    if ports == COMMON_PORTS:
        return "common"
    if not ports:
        return "top100"
    ordered = sorted(set(ports))
    chunks = []
    start = previous = ordered[0]
    for port in ordered[1:]:
        if port == previous + 1:
            previous = port
            continue
        chunks.append(str(start) if start == previous else "{}-{}".format(start, previous))
        start = previous = port
    chunks.append(str(start) if start == previous else "{}-{}".format(start, previous))
    return ",".join(chunks)


def resolve_ports(raw):
    """Parse a port spec into a sorted list of ints."""
    raw = raw.strip().lower()
    if raw in ("", "top100", "top"):
        return list(TOP_PORTS)
    if raw in ("common", "top10"):
        return list(COMMON_PORTS)
    ports = set()
    for part in raw.replace(",", " ").split():
        if "-" in part:
            try:
                a, b = (int(item) for item in part.split("-", 1))
            except ValueError:
                continue
            low, high = max(1, min(a, b)), min(65535, max(a, b))
            if low <= high:
                ports.update(range(low, high + 1))
        elif part.isdigit():
            p = int(part)
            if 1 <= p <= 65535:
                ports.add(p)
    return sorted(ports)


def configure(existing=None):
    """Run the interactive form and return a populated Settings object."""
    cfg = replace(existing) if existing is not None else Settings()

    _section("TARGET SETUP")
    target = _ask(
        "Target(s): domain / IP / URL, comma/space separated, or a file",
        default=cfg.targets or None,
        required=True,
    )
    cfg.targets = (target or "").strip()
    if not cfg.targets:
        raise ValueError("a target is required to continue")

    _section("MODULE SELECTION")
    width = ui.ui_width()
    print(ui.boxed(_module_rows(width), width=width))
    choice = _ask(
        "Select modules",
        default=_module_default(cfg.modules),
        choices=list(MODULE_MAP),
    )
    cfg.modules = list(MODULE_MAP.get(choice, MODULE_MAP["4"]))

    _section("PERFORMANCE & NETWORK")
    cfg.threads = _clamp(
        _ask("Threads / concurrency", default=str(cfg.threads), cast=int),
        THREADS_RANGE,
        "threads",
    )
    cfg.timeout = _clamp(
        _ask("Timeout per request (seconds)", default=str(cfg.timeout), cast=int),
        TIMEOUT_RANGE,
        "timeout",
    )
    cfg.proxy = _ask(
        "HTTP proxy URL (optional, e.g. http://127.0.0.1:8080)",
        default=cfg.proxy,
    )

    if "scanning" in cfg.modules:
        _section("SCAN OPTIONS")
        spec = _ask(
            "Ports (top100 / common / range / list)",
            default=_ports_default(cfg.ports),
        )
        cfg.ports = resolve_ports(spec)
        if not cfg.ports:
            print(ui.status("warn", "no usable ports; falling back to top100."))
            cfg.ports = list(TOP_PORTS)
        cfg.wordlist = _ask(
            "Directory wordlist file (optional; built-in if empty)",
            default=cfg.wordlist,
        )

    if "reputation" in cfg.modules:
        _section("API KEYS (OPTIONAL)")
        print(ui.status("info", "leave blank to skip third-party lookups."))
        cfg.vt_key = _ask("VirusTotal API key", default=cfg.vt_key)
        cfg.abuseipdb_key = _ask("AbuseIPDB API key", default=cfg.abuseipdb_key)
        cfg.safebrowsing_key = _ask(
            "Google Safe Browsing API key", default=cfg.safebrowsing_key
        )

    _section("OUTPUT")
    cfg.save_report = _ask(
        "Save reports to files? (y/n)",
        default="y" if cfg.save_report else "n",
        cast=bool,
    )
    if cfg.save_report:
        cfg.output_dir = _ask(
            "Output directory",
            default=cfg.output_dir or os.path.join(os.getcwd(), "reports"),
        )
    return cfg


def _module_names(modules):
    return " · ".join(name.capitalize() for name in modules) or "(none)"


def _ports_summary(cfg):
    selected = len(cfg.ports)
    if selected > cfg.max_ports:
        return "{} selected (first {})".format(selected, cfg.max_ports)
    return "{} selected".format(selected)


def summarize(cfg):
    """Return a boxed, human-readable summary of the current settings."""
    rows = [
        ("TARGETS", cfg.targets or "(none)"),
        ("MODULES", _module_names(cfg.modules)),
        ("THREADS", str(cfg.threads)),
        ("TIMEOUT", "{}s".format(cfg.timeout)),
        ("PROXY", cfg.proxy or "direct"),
        ("PORTS", _ports_summary(cfg) if "scanning" in cfg.modules else "n/a"),
        ("WORDLIST", cfg.wordlist or "built-in"),
        ("VIRUSTOTAL", "configured" if cfg.vt_key else "not set"),
        ("ABUSEIPDB", "configured" if cfg.abuseipdb_key else "not set"),
        ("SAFE BROWSING", "configured" if cfg.safebrowsing_key else "not set"),
        ("REPORTS", (cfg.output_dir or os.path.join(os.getcwd(), "reports"))
         if cfg.save_report else "disabled"),
    ]

    width = ui.ui_width()
    inner = max(10, width - 4)
    label_width = 16
    lines = []
    for key, value in rows:
        left = ui.style(key.ljust(label_width), "muted")
        right = ui.style(value, "body")
        gap = max(1, inner - ui.vlen(left) - ui.vlen(right))
        lines.append(left + " " * gap + right)

    return ui.boxed(
        lines,
        title="CURRENT CONFIGURATION",
        footer=ui.BRAND + "  ·  CONFIG",
        width=width,
    ) + "\n"
