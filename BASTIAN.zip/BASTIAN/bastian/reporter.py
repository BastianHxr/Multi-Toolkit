"""Plain-text report builder + file writer (kept color-free)."""

import os
import time


WIDTH = 80


def _center(text, width=WIDTH):
    text = text.strip()
    return text if len(text) >= width else text.center(width)


class Reporter:
    def __init__(self, target, scope=""):
        self.target = target
        self.scope = scope
        self.sections = []

    def add(self, title, lines):
        self.sections.append((title, list(lines) if lines else ["(no results)"],))

    def build(self):
        bar = "=" * WIDTH
        out = [
            bar,
            _center("BASTIAN"),
            _center("Security Research Report"),
            bar,
            "Target         : " + self.target,
            "Scope          : " + (self.scope or "full"),
            "Generated at   : " + time.strftime("%Y-%m-%d %H:%M:%S"),
            "",
        ]
        for title, lines in self.sections:
            out.append(bar)
            out.append(title)
            out.append(bar)
            out.extend(lines)
            out.append("")
        out.append(bar)
        out.append("END OF REPORT")
        out.append(bar)
        return "\n".join(out)

    def save(self, directory):
        os.makedirs(directory, exist_ok=True)
        safe = "".join(c if c.isalnum() or c in ".-_" else "_" for c in self.target)
        path = os.path.join(directory, f"{safe}_{int(time.time())}.txt")
        text = self.build()
        with open(path, "w", encoding="utf-8") as fh:
            fh.write(text + "\n")
        return path, text
