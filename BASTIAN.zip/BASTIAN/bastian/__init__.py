"""BASTIAN - an interactive multi-target security research toolkit.

Three integrated modules:
    * Analysis   - HTTP headers, SSL/TLS, DNS, WHOIS, tech fingerprinting
    * Scanning   - TCP port scan, directory brute-force, sensitive-file checks
    * Reputation - geolocation, URLhaus, DNSBL, VirusTotal/AbuseIPDB (optional keys)

Run ``python bs.py`` with no arguments to launch the interactive console
(single or multi target). Intended for authorized security research only.
"""

__version__ = "1.0.0"
