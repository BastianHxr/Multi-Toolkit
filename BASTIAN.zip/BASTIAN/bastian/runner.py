"""Multi-target orchestrator: run selected modules, print and save reports."""

import importlib

from . import color, ui
from .reporter import Reporter
from .target import load_targets


def _module(name):
    return importlib.import_module("bastian.modules." + name)


def execute(cfg):
    """Run all configured modules against all targets."""
    targets = load_targets(cfg.targets)
    if not targets:
        raise ValueError("no valid targets configured")
    results = []
    total = len(targets)
    print(ui.status("info", "loaded {} target(s)".format(total)))

    for idx, target in enumerate(targets, 1):
        heading = "TARGET {}/{} · {}".format(idx, total, target.label)
        print()
        print(ui.rule(heading, title_color="accent"))

        sections = []
        for mod_name in cfg.modules:
            try:
                sections += _module(mod_name).run(target, cfg)
            except Exception as exc:
                sections.append((mod_name.upper() + " [ERROR]", [str(exc)]))

        rep = Reporter(target.label, scope=", ".join(cfg.modules))
        for title, lines in sections:
            rep.add(title, lines)

        print(color.colorize_report(rep.build()))

        if cfg.save_report:
            directory = cfg.output_dir or "reports"
            try:
                path, _text = rep.save(directory)
                print()
                print(ui.status("ok", "saved: " + path))
            except OSError as exc:
                print()
                print(ui.status("err", "could not save report: {}".format(exc)))

        print()
        print(ui.rule())
        results.append((target, rep))

    return results
