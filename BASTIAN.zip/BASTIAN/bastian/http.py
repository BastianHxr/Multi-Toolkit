"""Minimal stdlib HTTP client (GET/POST/HEAD, redirects, proxy, SSL tolerant)."""

import gzip
import json
import ssl
import urllib.error
import urllib.request

DEFAULT_UA = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
    "AppleWebKit/537.36 (KHTML, like Gecko) "
    "Chrome/122.0.0.0 Safari/537.36"
)

_REDIRECT_CODES = {301, 302, 303, 307, 308}


def _unverified_context():
    ctx = ssl.create_default_context()
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE
    return ctx


class _NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


class Response:
    def __init__(self, status, headers, body, url, history=()):
        self.status = status
        self.headers = headers  # dict, lowercase keys
        self.text = body
        self.url = url
        self.history = tuple(history)

    def json(self):
        return json.loads(self.text) if self.text else None


class Client:
    def __init__(self, timeout=10, proxy=None, user_agent=DEFAULT_UA):
        self.timeout = timeout
        self.user_agent = user_agent
        self.proxy = proxy
        self._opener = self._build_opener()

    def _build_opener(self):
        handlers = [_NoRedirect(), urllib.request.HTTPHandler()]
        if self.proxy:
            handlers.append(urllib.request.ProxyHandler(self.proxy))
        else:
            handlers.append(urllib.request.ProxyHandler({}))
        # urllib.build_opener puts the default HTTPSHandler before our custom
        # ones, so pass a custom HTTPSHandler with permissive SSL context.
        ctx = _unverified_context()
        handlers.append(urllib.request.HTTPSHandler(context=ctx))
        return urllib.request.build_opener(*handlers)

    def _request(self, url, method="GET", data=None, headers=None, timeout=None,
                 follow_redirects=True, max_redirects=10):
        if not url.startswith(("http://", "https://")):
            url = "https://" + url
        headers = dict(headers or {})
        headers.setdefault("User-Agent", self.user_agent)
        headers.setdefault("Accept", "*/*")

        history = []
        current = url
        timeout = timeout or self.timeout

        for _ in range(max_redirects + 1):
            req = urllib.request.Request(current, data=data, headers=headers, method=method)
            try:
                with self._opener.open(req, timeout=timeout) as resp:
                    status = resp.status
                    hdrs = {k.lower(): v for k, v in resp.headers.items()}
                    body = resp.read()
                    if hdrs.get("content-encoding", "").lower() == "gzip":
                        try:
                            body = gzip.decompress(body)
                        except OSError:
                            pass
                    text = body.decode("utf-8", errors="replace")
                    final_url = resp.geturl()
            except urllib.error.HTTPError as exc:
                # HTTPError is also a response for 4xx/5xx.
                status = exc.code
                hdrs = {k.lower(): v for k, v in exc.headers.items()}
                try:
                    text = exc.read().decode("utf-8", errors="replace")
                except Exception:
                    text = ""
                final_url = exc.geturl() if hasattr(exc, "geturl") else current
            except (urllib.error.URLError, OSError, ValueError) as exc:
                return Response(0, {}, "", current, history)

            history.append((current, status))

            if follow_redirects and status in _REDIRECT_CODES and hdrs.get("location"):
                current = _absolutize(current, hdrs["location"])
                if method == "POST":
                    method = "GET"
                    data = None
                continue
            return Response(status, hdrs, text, final_url, history)

        return Response(0, {}, "too many redirects", current, history)

    def get(self, url, timeout=None, follow_redirects=True, headers=None):
        return self._request(url, "GET", timeout=timeout, headers=headers,
                             follow_redirects=follow_redirects)

    def head(self, url, timeout=None, follow_redirects=True, headers=None):
        return self._request(url, "HEAD", timeout=timeout, headers=headers,
                             follow_redirects=follow_redirects)

    def post(self, url, data=None, json_data=None, timeout=None, headers=None):
        payload = None
        hdrs = dict(headers or {})
        if json_data is not None:
            payload = json.dumps(json_data).encode("utf-8")
            hdrs["Content-Type"] = "application/json"
        elif data is not None:
            if isinstance(data, str):
                payload = data.encode("utf-8")
            else:
                payload = data
        return self._request(url, "POST", data=payload, headers=hdrs, timeout=timeout,
                             follow_redirects=False)


def _absolutize(current, location):
    from urllib.parse import urljoin
    return urljoin(current, location)
