"""Sentinel ANSI UI: lime-to-cyan palette, block frames and status lines.

The console uses solid block borders, gradient rules and truecolor output.
Everything degrades to plain text when color is disabled or output is piped.
"""

import os
import re
import shutil
import time

from . import color

HEX = {
    "primary": "a3e635",
    "accent": "22d3ee",
    "ok": "4ade80",
    "warn": "facc15",
    "err": "fb7185",
    "info": "60a5fa",
    "muted": "8b9bb4",
    "frame": "4d7c0f",
    "body": "e2e8f0",
    "bright": "f8fafc",
}

GRADIENT_START = (0xA3, 0xE6, 0x35)
GRADIENT_END = (0x22, 0xD3, 0xEE)

BRAND = "BASTIAN // SENTINEL"
AUTHOR = "coded by: t.me/BastianHxr13"

RESET = "\x1b[0m"
_ANSI = re.compile(r"\x1b\[[0-9;]*m")

BOX = {
    "block": ("▛", "▜", "▙", "▟", "▀", "▄", "▌", "▐"),
    "heavy": ("┏", "┓", "┗", "┛", "━", "━", "┃", "┃"),
    "round": ("╭", "╮", "╰", "╯", "─", "─", "│", "│"),
    "single": ("┌", "┐", "└", "┘", "─", "─", "│", "│"),
}


def enabled():
    return bool(color.ENABLED) or bool(os.environ.get("FORCE_COLOR"))


def _rgb(name):
    code = HEX.get(name, HEX["body"]).lstrip("#")
    return tuple(int(code[i:i + 2], 16) for i in (0, 2, 4))


def c(name):
    """Truecolor escape for a named palette color ('' when disabled)."""
    if not enabled():
        return ""
    r, g, b = _rgb(name)
    return "\x1b[38;2;%d;%d;%dm" % (r, g, b)


def style(text, name, bold=False):
    """Wrap text in a named truecolor, optionally bold."""
    if not enabled():
        return str(text) if text else ""
    prefix = "\x1b[1m" if bold else ""
    return prefix + c(name) + str(text) + RESET


def style_rgb(text, rgb, bold=False):
    """Wrap text in an explicit RGB tuple."""
    if not enabled():
        return str(text) if text else ""
    prefix = "\x1b[1m" if bold else ""
    return prefix + "\x1b[38;2;%d;%d;%dm" % tuple(rgb) + str(text) + RESET


def vlen(text):
    """Visible length (ANSI escapes stripped)."""
    return len(_ANSI.sub("", str(text)))


def term_width():
    try:
        return shutil.get_terminal_size((100, 30)).columns
    except Exception:
        return 100


def ui_width():
    return max(58, min(92, term_width() - 2))


def gradient(text, start=None, end=None):
    """Horizontal per-character gradient (spaces stay transparent)."""
    text = str(text).replace("\t", "  ")
    if not enabled():
        return text
    start = start or GRADIENT_START
    end = end or GRADIENT_END
    n = len(text)
    out = []
    for i, ch in enumerate(text):
        if ch == " ":
            out.append(ch)
            continue
        ratio = i / (n - 1) if n > 1 else 0
        col = tuple(round(a + (b - a) * ratio) for a, b in zip(start, end))
        out.append("\x1b[38;2;%d;%d;%dm" % col + ch + RESET)
    return "".join(out)


def clock_now():
    """Local time with a UTC offset suffix, e.g. '07:32:11 UTC+7'."""
    now = time.localtime()
    west = time.altzone if now.tm_isdst > 0 else time.timezone
    offset = -west
    sign = "-" if offset < 0 else "+"
    hours, minutes = divmod(abs(offset) // 60, 60)
    zone = "UTC%s%d" % (sign, hours) + (":%02d" % minutes if minutes else "")
    return time.strftime("%H:%M:%S", now) + " " + zone


def _boxc(style_name):
    return BOX.get(style_name, BOX["block"])


def _fit(text, limit):
    """Keep a line inside the frame; strip colors only when truncating."""
    text = str(text)
    if vlen(text) <= limit:
        return text
    plain = _ANSI.sub("", text)
    if limit <= 1:
        return plain[:limit]
    return plain[:limit - 1] + "…"


def boxed(lines, title=None, footer=None, width=None, box="block",
          title_color="accent", footer_color="muted"):
    """Render a block-framed panel with optional title and footer plates."""
    width = max(40, int(width or ui_width()))
    tl, tr, bl, br, htop, hbot, vleft, vright = _boxc(box)
    inner = width - 2
    out = []

    if title:
        label = _fit(" " + str(title) + " ", inner)
        vis = vlen(label)
        left = max(0, (inner - vis) // 2)
        right = max(0, inner - vis - left)
        out.append(
            gradient(tl + htop * left, GRADIENT_START, GRADIENT_END)
            + style(label, title_color, bold=True)
            + gradient(htop * right + tr, GRADIENT_START, GRADIENT_END)
        )
    else:
        out.append(gradient(tl + htop * inner + tr, GRADIENT_START, GRADIENT_END))

    limit = inner - 2
    for line in lines:
        text = _fit(str(line), limit)
        pad = max(0, limit - vlen(text))
        out.append(
            style(vleft, "primary") + " " + text + " " * pad
            + " " + style(vright, "accent")
        )

    if footer:
        label = _fit(" " + str(footer) + " ", inner)
        vis = vlen(label)
        left = max(0, (inner - vis) // 2)
        right = max(0, inner - vis - left)
        out.append(
            gradient(bl + hbot * left, GRADIENT_START, GRADIENT_END)
            + style(label, footer_color)
            + gradient(hbot * right + br, GRADIENT_START, GRADIENT_END)
        )
    else:
        out.append(gradient(bl + hbot * inner + br, GRADIENT_START, GRADIENT_END))

    return "\n".join(out)


def rule(title=None, width=None, title_color="accent", char="━"):
    """A gradient horizontal rule with an optional centered plate."""
    width = max(40, int(width or ui_width()))
    if not title:
        return gradient(char * width, GRADIENT_START, GRADIENT_END)
    label = _fit("┤ " + str(title) + " ├", width)
    vis = vlen(label)
    left = max(0, (width - vis) // 2)
    right = max(0, width - vis - left)
    return (
        gradient(char * left, GRADIENT_START, GRADIENT_END)
        + style(label, title_color, bold=True)
        + gradient(char * right, GRADIENT_START, GRADIENT_END)
    )


def keycap(value):
    """A compact menu key, e.g. '[ 1 ]'."""
    return style("[", "muted") + style(" " + str(value) + " ", "primary", bold=True) + style("]", "muted")


STATUS_STYLES = {
    "ok": ("[ OK ]", "ok", "✓"),
    "err": ("[FAIL]", "err", "×"),
    "warn": ("[WARN]", "warn", "!"),
    "info": ("[INFO]", "info", "›"),
    "prog": ("[ RUN]", "primary", "▸"),
    "tip": ("[ TIP]", "accent", "?"),
}


def status(kind, message):
    """One-line status display with a colored tag and rail."""
    label, color_name, glyph = STATUS_STYLES.get(kind, STATUS_STYLES["info"])
    tag = style(label, color_name, bold=True)
    rail = style("▌", color_name)
    return (
        "  " + rail + " " + tag + " "
        + style(glyph, color_name, bold=True) + " "
        + style(message, "body")
    )
