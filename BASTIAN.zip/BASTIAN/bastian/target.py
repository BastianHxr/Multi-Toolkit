"""Target normalization and multi-target loading."""

import ipaddress
import os
import re
from urllib.parse import urlsplit


class Target:
    """A normalized scan target."""

    def __init__(self, original, host, port=None, scheme="https"):
        self.original = original.strip()
        self.host = host
        self.scheme = scheme
        self.port = port
        self.is_ip = _is_ip(host)

    @property
    def label(self):
        if self.port and self.port != default_port(self.scheme):
            return f"{self.host}:{self.port}"
        return self.host

    @property
    def base_url(self):
        if self.port and self.port != default_port(self.scheme):
            return f"{self.scheme}://{self.host}:{self.port}"
        return f"{self.scheme}://{self.host}"

    def __repr__(self):  # pragma: no cover - developer helper
        return f"Target({self.label!r}, scheme={self.scheme!r})"


def default_port(scheme):
    return 443 if scheme == "https" else 80


def _is_ip(value):
    try:
        ipaddress.ip_address(value)
        return True
    except ValueError:
        return False


def normalize_token(raw):
    """Convert a single user token into a Target."""
    token = raw.strip()
    if not token:
        return None

    # Strip any trailing path from a full URL.
    token = token.split("#")[0].split("?")[0]

    scheme = "https"
    host_port = token

    if "://" in token:
        parts = urlsplit(token)
        if parts.scheme:
            scheme = parts.scheme.lower()
        host_port = parts.netloc or parts.path
    elif not _is_ip(token) and "/" in token and "." in token:
        # Bare "host/path" -> take the host only.
        host_port = token.split("/")[0]

    host, port = _split_host_port(host_port, scheme)
    if not host:
        return None
    return Target(original=raw, host=host, port=port, scheme=scheme)


def _split_host_port(value, scheme):
    # IPv6 literal: [::1]:8080 or [::1]
    if value.startswith("["):
        end = value.find("]")
        if end != -1:
            host = value[1:end]
            rest = value[end + 1 :]
            port = int(rest[1:]) if rest.startswith(":") and rest[1:].isdigit() else None
            return host, port

    # Normal host:port (only when there is a single colon and a numeric port).
    if value.count(":") == 1:
        host, maybe_port = value.rsplit(":", 1)
        if maybe_port.isdigit():
            return host, int(maybe_port)
        return value, None
    return value, None


def _looks_like_file(text):
    """Heuristic: a single token that is an existing file path."""
    text = text.strip()
    if any(ch in text for ch in (",", " ", "\n")):
        return None
    expanded = os.path.expanduser(text)
    if os.path.isfile(expanded):
        return expanded
    return None


def load_targets(raw):
    """Parse user input into a list of Target objects.

    Accepts comma/whitespace/newline separated tokens, or a path to a file
    containing one target per line ('#' comments supported). Raises ValueError
    when nothing usable is found.
    """
    raw = (raw or "").strip()
    if not raw:
        return []

    file_path = _looks_like_file(raw)
    if file_path:
        with open(file_path, "r", encoding="utf-8", errors="ignore") as fh:
            raw = fh.read()

    targets = []
    seen = set()
    for token in re.split(r"[,\s]+", raw):
        token = token.strip()
        if not token or token.startswith("#"):
            continue
        t = normalize_token(token)
        if t and t.label.lower() not in seen:
            seen.add(t.label.lower())
            targets.append(t)

    if not targets:
        raise ValueError("no valid targets found in input")
    return targets
