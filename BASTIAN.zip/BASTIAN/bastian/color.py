"""ANSI color helpers.

Provides Windows VT enablement, TTY auto-detection, truecolor tags and small
paint helpers. Report files stay plain text; colors are applied only when
printing to a TTY, so redirected/saved output never contains escape garbage.
"""

import os
import re
import sys

_STYLES = {
    "reset": "\033[0m",
    "bold": "\033[1m",
    "dim": "\033[2m",
    "underline": "\033[4m",
    "black": "\033[30m",
    "red": "\033[31m",
    "green": "\033[32m",
    "yellow": "\033[33m",
    "blue": "\033[34m",
    "magenta": "\033[35m",
    "cyan": "\033[36m",
    "white": "\033[37m",
    "gray": "\033[90m",
    "bright_red": "\033[91m",
    "bright_green": "\033[92m",
    "bright_yellow": "\033[93m",
    "bright_blue": "\033[94m",
    "bright_magenta": "\033[95m",
    "bright_cyan": "\033[96m",
    "bright_white": "\033[97m",
}

ENABLED = False


def enable_windows_vt():
    """Enable ANSI escape processing on the Windows console (no-op elsewhere)."""
    if os.name != "nt":
        return
    try:
        import ctypes

        kernel32 = ctypes.windll.kernel32
        kernel32.GetStdHandle.restype = ctypes.c_void_p
        kernel32.GetStdHandle.argtypes = [ctypes.c_int]
        # -11 = STD_OUTPUT_HANDLE, -12 = STD_ERROR_HANDLE
        for std_handle in (-11, -12):
            handle = kernel32.GetStdHandle(std_handle)
            if not handle:
                continue
            mode = ctypes.c_uint32()
            if kernel32.GetConsoleMode(handle, ctypes.byref(mode)):
                # ENABLE_VIRTUAL_TERMINAL_PROCESSING = 0x0004
                kernel32.SetConsoleMode(handle, mode.value | 0x0004)
    except Exception:
        pass


def set_enabled(value):
    """Turn color output on/off globally. Enables VT when turning on."""
    global ENABLED
    ENABLED = bool(value)
    if ENABLED:
        enable_windows_vt()


def auto_enable():
    """Enable color based on environment and TTY."""
    if os.environ.get("NO_COLOR"):
        set_enabled(False)
        return False
    if os.environ.get("FORCE_COLOR"):
        set_enabled(True)
        return True
    set_enabled(sys.stdout.isatty() and sys.stderr.isatty())
    return ENABLED


def paint(text, *codes):
    """Wrap text in the given style codes. No-op when color is disabled."""
    if not ENABLED or not text:
        return text
    prefix = "".join(_STYLES.get(c, "") for c in codes)
    return f"{prefix}{text}{_STYLES['reset']}"


def _rgb(hex_code):
    code = hex_code.lstrip("#")
    return tuple(int(code[i:i + 2], 16) for i in (0, 2, 4))


def truecolor(text, hex_code, bold=False):
    """Paint text in a 24-bit color. No-op when color is disabled."""
    if not ENABLED or not text:
        return text
    r, g, b = _rgb(hex_code)
    prefix = "\033[1m" if bold else ""
    return "{}\033[38;2;{};{};{}m{}\033[0m".format(prefix, r, g, b, text)


# Status glyphs kept for compatibility with older callers.
OK = "+"        # success / present
FAIL = "!"      # error / missing / flagged
INFO = "*"      # neutral info
PROG = "~"      # progress / in-flight
VILL = "#"      # vulnerability / suspicious finding

_TAGS = {
    "ok": ("[ OK ]", "4ade80"),
    "fail": ("[FAIL]", "fb7185"),
    "err": ("[FAIL]", "fb7185"),
    "info": ("[INFO]", "60a5fa"),
    "prog": ("[ RUN]", "a3e635"),
    "run": ("[ RUN]", "a3e635"),
    "vuln": ("[ALERT]", "f87171"),
    "alert": ("[ALERT]", "f87171"),
    "warn": ("[WARN]", "facc15"),
}


def tag(state):
    """Map a short state name to a fixed-width truecolor label."""
    label, hex_code = _TAGS.get(str(state).lower(), _TAGS["info"])
    return truecolor(label, hex_code, bold=True)


def bar(width=80, char="━", start="a3e635", end="22d3ee"):
    """A lime-to-cyan horizontal rule (plain when color is disabled)."""
    width = max(1, int(width))
    if not ENABLED:
        return char * width
    r1, g1, b1 = _rgb(start)
    r2, g2, b2 = _rgb(end)
    out = []
    for i in range(width):
        ratio = i / max(width - 1, 1)
        r = round(r1 + (r2 - r1) * ratio)
        g = round(g1 + (g2 - g1) * ratio)
        b = round(b1 + (b2 - b1) * ratio)
        out.append("\033[38;2;{};{};{}m{}\033[0m".format(r, g, b, char))
    return "".join(out)


def section(title, width=80):
    """A framed section heading for plain-text report display."""
    label = str(title).upper()
    plate = "[ {} ]".format(label)
    pad = max(0, (width - len(plate)) // 2)
    return "{line}\n{pad}{plate}\n{line}".format(
        line=bar(width),
        pad=" " * pad,
        plate=truecolor(plate, "22d3ee", bold=True),
    )


_HTTP_RE = re.compile(r"HTTP \d{3}")


def _http_repl(match):
    code = match.group(0)[-3:]
    if code.startswith("2"):
        return truecolor(match.group(0), "4ade80")
    if code.startswith("3"):
        return truecolor(match.group(0), "facc15")
    return truecolor(match.group(0), "fb7185")


def colorize_report(text):
    """Add color to a plain report body for terminal display."""
    if not ENABLED or not text:
        return text
    out = []
    for line in text.split("\n"):
        stripped = line.strip()
        if stripped and set(stripped) == {"="}:
            out.append(truecolor(line, "4d7c0f", bold=True))
        elif stripped and set(stripped) == {"-"}:
            out.append(paint(line, "dim"))
        elif stripped.isupper() and len(stripped) < 30:
            out.append(truecolor(line, "22d3ee", bold=True))
        else:
            line = line.replace(
                "[MISSING]", truecolor("[MISSING]", "fb7185", bold=True)
            ).replace(
                "[PRESENT]", truecolor("[PRESENT]", "4ade80", bold=True)
            ).replace(
                "[FLAGGED]", truecolor("[FLAGGED]", "f87171", bold=True)
            )
            line = _HTTP_RE.sub(_http_repl, line)
            out.append(line)
    return "\n".join(out)
