"""BASTIAN banner: sentinel shield, custom wordmark and block frame."""

from . import __version__
from . import ui


ART = [
    "          ▄▄▄▄▄▄▄▄▄",
    "       ▄█████████████████▄",
    "     ▄█████████████████████▄",
    "    █████████████████████████",
    "   ███████████████████████████",
    "   ██████████▀▀▀▀▀▀▀██████████",
    "   █████████   @@@   █████████",
    "   █████████   @@@   █████████",
    "   ██████████▄▄███▄▄██████████",
    "    █████████████████████████",
    "     ▀█████████████████████▀",
    "       ▀▀███████████████▀▀",
    "           ▀▀▀▀▀▀▀▀▀▀▀",
]

LOGO_FONT = {
    "B": ["████ ", "█   █", "████ ", "█   █", "████ "],
    "A": [" ███ ", "█   █", "█████", "█   █", "█   █"],
    "S": ["████ ", "█    ", "████ ", "    █", "████ "],
    "T": ["█████", "  █  ", "  █  ", "  █  ", "  █  "],
    "I": ["█████", "  █  ", "  █  ", "  █  ", "█████"],
    "N": ["█   █", "██  █", "█ █ █", "█  ██", "█   █"],
}
LOGO_ROWS = 5
LOGO_BLANK = " " * 5

TAGLINE = "Multi-Target Security Research Toolkit"


def _paint_art(line):
    """Gradient the shield, with the keyhole highlighted in accent cyan."""
    if "@" not in line:
        return ui.gradient(line)
    out = []
    buffer = ""
    for char in line:
        if char == "@":
            if buffer:
                out.append(ui.gradient(buffer))
                buffer = ""
            out.append(ui.style("█", "accent", bold=True))
        else:
            buffer += char
    if buffer:
        out.append(ui.gradient(buffer))
    return "".join(out)


def _wordmark(word):
    lines = []
    for row in range(LOGO_ROWS):
        glyphs = [LOGO_FONT.get(char.upper(), [LOGO_BLANK] * LOGO_ROWS)[row]
                  for char in word]
        lines.append(" ".join(glyphs).rstrip())
    return lines


def _center(text, width):
    vis = ui.vlen(text)
    left = max(0, (width - vis) // 2)
    return " " * left + text + " " * max(0, width - vis - left)


def banner(width=None):
    width = max(52, int(width or ui.ui_width()))
    inner = width - 2
    body = []

    for line in ART:
        body.append(_center(_paint_art(line), inner - 2))
    body.append("")

    for row, line in enumerate(_wordmark("BASTIAN")):
        ratio = row / max(LOGO_ROWS - 1, 1)
        color = tuple(
            round(a + (b - a) * ratio)
            for a, b in zip(ui.GRADIENT_START, ui.GRADIENT_END)
        )
        body.append(_center(ui.style_rgb(line, color, bold=True), inner - 2))

    body.append("")
    body.append(_center(ui.style(TAGLINE, "muted"), inner - 2))
    caption = (
        ui.style(ui.AUTHOR, "muted")
        + ui.style("  ·  ", "frame")
        + ui.style("v" + __version__, "accent")
    )
    body.append(_center(caption, inner - 2))

    return "\n" + ui.boxed(
        body,
        title="BASTIAN // SENTINEL",
        footer="ANALYSIS  ·  SCANNING  ·  REPUTATION",
        width=width,
    ) + "\n"
